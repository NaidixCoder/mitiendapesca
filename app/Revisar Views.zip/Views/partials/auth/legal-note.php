<p class="text-xs text-[color:var(--muted)] mt-4">
  Al continuar aceptás los <a class="underline" href="<?= url('/terminos') ?>">Términos y Condiciones</a>
  y la <a class="underline" href="<?= url('/privacidad') ?>">Política de Privacidad</a>.
</p>
