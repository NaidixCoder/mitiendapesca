<p class="text-sm text-[color:var(--muted)]">Próximamente: productos relacionados, upsell/cross-sell.</p>
