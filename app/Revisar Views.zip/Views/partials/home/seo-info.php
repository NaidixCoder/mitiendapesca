<section class="py-12">
    <div class="max-w-7xl mx-auto px-4 md:px-8">
        <div class="prose max-w-none prose-headings:font-semibold prose-p:text-gray-600">
            <h2>Tu tienda de pesca en Argentina</h2>
            <p>Somos pescadores. Probamos, seleccionamos y recomendamos equipos que rinden en río, laguna y mar. Envíos
                a todo el país y soporte real post-venta.</p>
            <h3>Marcas y categorías</h3>
            <p>Shimano, Okuma, Abu, Rapala, Owner y más. Cañas, reels, multifilamentos, señuelos, cajas y accesorios
                técnicos.</p>
        </div>
    </div>
</section>