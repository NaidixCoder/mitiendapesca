<a href="<?= base_url('/') ?>" class="block hover:opacity-80 transition" aria-label="Ir al inicio">
    <img src="<?= asset('img/branding/miPescaYaventura-leyenda.png') ?>" alt="Mi Pesca & Aventura" class="h-12 w-auto" />
</a>
