<?php http_response_code(403); ?>
<section class="max-w-3xl mx-auto p-8">
    <h1 class="text-2xl font-bold">403 — Acceso denegado</h1>
    <p class="mt-2 text-sm opacity-80">No tenés permisos para ver esta sección.</p>
</section>
