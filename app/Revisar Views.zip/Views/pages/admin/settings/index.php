<section class="max-w-5xl mx-auto p-6">
  <h1 class="text-2xl font-bold text-slate-100">Ajustes</h1>
  <p class="text-slate-400 mt-2">Próximamente: branding, CSP, llaves y políticas.</p>
</section>
