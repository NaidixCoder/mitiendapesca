<?php
/**
 * Helpers de vistas y layout
 * Dependencias: base_path(), base_url(); (e()) opcional
 */

if (!function_exists('render_page')) {
  function render_page(string $name, array $vars = []): void {
    $viewsDir = base_path('app/Views');
    $head   = $viewsDir.'/partials/head.php';
    $header = $viewsDir.'/partials/header/header.php';
    $footer = $viewsDir.'/partials/footer.php';
    $page   = $viewsDir.'/pages/'.$name.'.php';

    if (!empty($vars)) extract($vars, EXTR_SKIP);

    echo "<!-- RENDER start: {$name} -->\n";
    if (is_file($head))   include $head;
    if (is_file($header)) include $header;

    if (is_file($page)) {
      include $page;
    } else {
      http_response_code(404);
      $esc = function($v){ return function_exists('e') ? e($v) : htmlspecialchars((string)$v, ENT_QUOTES,'UTF-8'); };
      echo '<main class="container mx-auto p-6"><h1>Vista no encontrada</h1><p>'.$esc($name).'</p></main>';
    }

    if (is_file($footer)) include $footer;
    echo "\n<!-- RENDER end: {$name} -->\n";
  }
}

if (!function_exists('section')) {
  function section(string $path, array $vars = []): void {
    $candidates = [
      base_path('app/Views/partials/' . ltrim($path,'/') . '.php'),
      base_path('app/Views/' . ltrim($path,'/') . '.php'),
    ];
    if (!empty($vars)) extract($vars, EXTR_SKIP);
    foreach ($candidates as $file) {
      if (is_file($file)) { include $file; return; }
    }
    echo "<!-- section missing: ".htmlspecialchars($path, ENT_QUOTES,'UTF-8')." -->";
  }
}

if (!function_exists('flash')) {
  function flash(?string $key=null, $val=null) {
    if (session_status() !== PHP_SESSION_ACTIVE) @session_start();
    if ($key === null) { $all = $_SESSION['flash'] ?? []; unset($_SESSION['flash']); return $all; }
    if ($val === null) { $v = $_SESSION['flash'][$key] ?? null; unset($_SESSION['flash'][$key]); return $v; }
    $_SESSION['flash'][$key] = $val; return null;
  }
}

if (!function_exists('redirect')) {
  function redirect(string $path) { header('Location: '.base_url($path)); exit; }
}

if (!function_exists('json')) {
  function json($data, int $status = 200): void {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    exit;
  }
}
