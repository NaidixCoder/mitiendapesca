<?php
namespace App\Controllers\Admin;

class SettingsController extends BaseController {
    public function index(){ render_page('admin/settings/index'); }
}
